#/bin/sh
/usr/bin/img2pdf $1 $2 $3 > /dev/null & echo $!
