<html>
 <head>
  <title>Watch OCR</title>

 </head>
 <body>
<table><tr><td><a href="/"> <img src="Logo2.jpg" style="border-style: none"/></a></td><td align="center">
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="PTAG7Y7RM7MH8">
<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit"
alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form><a>If you find this product useful and would like to see it improved, please donate.</a></td></tr></table>

<b><p>Watch OCR PDF Server Control</p></b> 

<?php

$scanin = $_POST['scanin'];
$scanout = $_POST['scanout'];
$preserve = $_POST['preserve'];
$preservepath = $_POST['preservepath'];
$resolution = $_POST['resolution'];
$deskew = $_POST['deskew'];
$barcode = $_POST['barcode'];
$autorotate = $_POST['autorotate'];
$autorotateall = $_POST['autorotateall'];


if ($preserve == "True")
$Command = "/var/www/startpdf.sh -i" . $scanin . " -o" . $scanout . " -m -p" . $preservepath . " -r" . $resolution;
else 
$Command = "/var/www/startpdf.sh -i" . $scanin . " -o" . $scanout . " -m -r" . $resolution;

if ($deskew == "True")
$Command = $Command . " -d";

if ($barcode == "True")
$Command = $Command . " -z";

if ($autorotate == "True")
$Command = $Command . " -b";

if ($autorotateall == "True")
$Command = $Command . " -a";

//print ($Command);
// Execute the shell command

//shell_exec("nohup $Command 2> /dev/null & echo $!");
$PID = shell_exec("nohup $Command 2> /dev/null");

//return execute status;
echo '<button type="button" onClick="window.location=\'stop.php?pid='. trim(strval($PID)) . '\'">Stop Watch OCR PDF Server </button>';
echo "</br>";

?>

<p>OCR Server Status = Started</p>

<?php
echo '<a href="status.php?pid='. trim(strval($PID)) . '" target="_blank">Live Server Status</a>';
?>

</br>

</body>
</html>
