<META HTTP-EQUIV="Refresh" CONTENT="15">
<html>
<head>
<script>
function go(){
setTimeout("window.location='#bottom'",1);
}
</script>
</head>
<body onload='go()'>
<?php
$PID = $_GET['pid'];

include("status/watchocr.log");

exec("ps $PID", $ProcessState);
if (count($ProcessState) >=2)
echo '</br></br><b><a>WatchOCR PDF Server Status = Running</a></b>';
else
echo '</br></br><b><a>WatchOCR PDF Server Status = Stopped</a></b>';

?>
</table>
<a name='bottom'>&nbsp</a>
</body>
</html>
